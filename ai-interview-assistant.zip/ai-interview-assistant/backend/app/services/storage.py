from sqlalchemy.orm import Session
from ..models.candidate import Candidate
from ..models.interview import Interview

def create_candidate(db: Session, data: dict) -> Candidate:
    c = Candidate(**data)
    db.add(c); db.commit(); db.refresh(c); return c

def list_candidates(db: Session):
    return db.query(Candidate).order_by(Candidate.final_score.desc().nullslast()).all()

def get_candidate(db: Session, cid: int):
    return db.get(Candidate, cid)

def start_interview(db: Session, candidate_id: int, qa: list[dict]) -> Interview:
    it = Interview(candidate_id=candidate_id, qa=qa, status="in_progress")
    db.add(it); db.commit(); db.refresh(it); return it

def get_interview(db: Session, iid: int) -> Interview | None:
    return db.get(Interview, iid)

def save_interview(db: Session, it: Interview):
    db.add(it); db.commit(); db.refresh(it); return it
