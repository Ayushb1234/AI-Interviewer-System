import re

EMAIL_RE = re.compile(r"[\w\.-]+@[\w\.-]+")
PHONE_RE = re.compile(r"(?:\+\d{1,3}[- ]?)?\d{10}")

def extract_from_text(text: str) -> dict:
    email = EMAIL_RE.search(text)
    phone = PHONE_RE.search(text)
    # naive "name" = first non-empty line
    name = next((ln.strip() for ln in text.splitlines() if ln.strip()), None)
    return {
        "name": name,
        "email": email.group(0) if email else None,
        "phone": phone.group(0) if phone else None,
    }

def parse_pdf(file_bytes: bytes) -> dict:
    # simple fallback (replace with pdfplumber for real parsing)
    text = file_bytes.decode(errors="ignore")
    return extract_from_text(text)

def parse_docx(file_bytes: bytes) -> dict:
    # simple fallback (replace with python-docx for real parsing)
    text = file_bytes.decode(errors="ignore")
    return extract_from_text(text)
