import random

QUESTION_BANK = {
    "easy": [
        "Explain the difference between var, let, and const in JavaScript.",
        "What are React hooks and when would you use useEffect?",
    ],
    "medium": [
        "How does React reconciliation work? What triggers re-renders?",
        "Design a REST API for a Todo app with authentication and rate limiting.",
    ],
    "hard": [
        "How would you scale a Node.js service that faces bursty traffic spikes?",
        "Explain trade-offs of server-side rendering vs. client-side rendering in React.",
    ],
}

DURATIONS = {"easy": 20, "medium": 60, "hard": 120}

def generate_interview():
    qs = []
    for diff, count in (("easy", 2), ("medium", 2), ("hard", 2)):
        picks = random.sample(QUESTION_BANK[diff], k=min(count, len(QUESTION_BANK[diff])))
        for q in picks:
            qs.append({"q": q, "difficulty": diff, "timeLimit": DURATIONS[diff], "answer": None, "score": None})
    return qs

def score_answer(question: str, answer: str, difficulty: str) -> int:
    base = {"easy": 10, "medium": 20, "hard": 30}[difficulty]
    if not answer:
        return 0
    # toy heuristic scorer
    bonus = 0
    for kw in ["time complexity", "trade-off", "hooks", "state", "scale", "cache", "queue", "memo", "retries", "circuit breaker"]:
        if kw in answer.lower():
            bonus += 2
    bonus += min(len(answer) // 80, 10)
    return max(0, min(base + bonus, base))
