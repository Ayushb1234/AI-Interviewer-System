# backend/app/config.py
from typing import List, Optional
from pydantic_settings import BaseSettings  # ⬅️ changed import

class Settings(BaseSettings):
    APP_NAME: str = "AI Interview Assistant"
    BACKEND_CORS_ORIGINS: List[str] = ["http://localhost:5173", "*"]
    OPENAI_API_KEY: Optional[str] = None
    DB_URL: str = "sqlite:///./data.db"  # local dev

settings = Settings()
