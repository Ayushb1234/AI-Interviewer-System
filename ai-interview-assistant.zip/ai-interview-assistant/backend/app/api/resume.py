from fastapi import APIRouter, UploadFile, File, HTTPException, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..services import resume_parser, storage

router = APIRouter(prefix="/resume", tags=["resume"])

@router.post("/upload")
async def upload_resume(file: UploadFile = File(...), db: Session = Depends(get_db)):
    content = await file.read()
    fname = (file.filename or "").lower()
    if fname.endswith(".pdf"):
        meta = resume_parser.parse_pdf(content)
    elif fname.endswith(".docx"):
        meta = resume_parser.parse_docx(content)
    else:
        raise HTTPException(400, "Only PDF/DOCX supported")

    missing = [k for k in ("name", "email", "phone") if not meta.get(k)]
    candidate = storage.create_candidate(db, {
        "name": meta.get("name"), "email": meta.get("email"),
        "phone": meta.get("phone"), "resume_meta": meta
    })
    return {"candidate_id": candidate.id, "extracted": meta, "missing_fields": missing}
