from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.orm import Session
from ..db import get_db, Base, engine
from ..services import storage
from ..services.ai_engine import generate_interview, score_answer
from ..schemas.interview import StartInterviewReq, AnswerReq, InterviewOut

Base.metadata.create_all(bind=engine)

router = APIRouter(prefix="/interview", tags=["interview"])

@router.post("/start", response_model=InterviewOut)
def start(req: StartInterviewReq, db: Session = Depends(get_db)):
    qa = generate_interview()
    it = storage.start_interview(db, req.candidate_id, qa)
    return it

@router.post("/answer", response_model=InterviewOut)
def answer(req: AnswerReq, db: Session = Depends(get_db)):
    it = storage.get_interview(db, req.interview_id)
    if not it:
        raise HTTPException(404, "Interview not found")
    if req.index < 0 or req.index >= len(it.qa):
        raise HTTPException(400, "Bad index")
    qa = it.qa
    qa[req.index]["answer"] = req.answer
    qa[req.index]["score"] = score_answer(qa[req.index]["q"], req.answer, qa[req.index]["difficulty"])
    it.qa = qa
    storage.save_interview(db, it)
    return it

@router.post("/finish", response_model=InterviewOut)
def finish(interview_id: int, db: Session = Depends(get_db)):
    it = storage.get_interview(db, interview_id)
    if not it:
        raise HTTPException(404, "Interview not found")
    it.status = "finished"
    total = sum((item.get("score") or 0) for item in it.qa)
    cand = storage.get_candidate(db, it.candidate_id)
    if cand:
        cand.final_score = total
        diffs = {i["difficulty"] for i in it.qa if (i.get("score") or 0) > 0}
        cand.summary = f"Final score: {total}. Strengths: {', '.join(sorted(diffs)) or '—'}."
        db.add(cand); db.commit()
    storage.save_interview(db, it)
    return it
