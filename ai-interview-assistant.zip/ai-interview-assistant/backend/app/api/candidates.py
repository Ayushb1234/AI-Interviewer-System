from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..services import storage
from ..schemas.candidate import CandidateOut

router = APIRouter(prefix="/candidates", tags=["candidates"])

@router.get("/", response_model=list[CandidateOut])
def list_all(db: Session = Depends(get_db)):
    return storage.list_candidates(db)

@router.get("/{candidate_id}", response_model=CandidateOut)
def by_id(candidate_id: int, db: Session = Depends(get_db)):
    return storage.get_candidate(db, candidate_id)
