from pydantic import BaseModel
from typing import List, Optional, Literal

Difficulty = Literal["easy", "medium", "hard"]

class QAItem(BaseModel):
    q: str
    difficulty: Difficulty
    timeLimit: int
    answer: Optional[str] = None
    score: Optional[int] = None

class StartInterviewReq(BaseModel):
    candidate_id: int

class AnswerReq(BaseModel):
    interview_id: int
    index: int
    answer: str

class InterviewOut(BaseModel):
    id: int
    candidate_id: int
    status: str
    qa: List[QAItem]
    class Config:
        from_attributes = True
