from pydantic import BaseModel  # ⬅ keep it simple
from typing import Optional

class CandidateCreate(BaseModel):
    name: Optional[str] = None
    email: Optional[str] = None     # ⬅ was EmailStr
    phone: Optional[str] = None

class CandidateOut(BaseModel):
    id: int
    name: Optional[str]
    email: Optional[str]             # ⬅ was EmailStr
    phone: Optional[str]
    final_score: Optional[int]
    summary: Optional[str]
    resume_meta: Optional[dict]
    class Config:
        from_attributes = True
