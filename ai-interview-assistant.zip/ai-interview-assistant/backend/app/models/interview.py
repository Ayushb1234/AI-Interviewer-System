from sqlalchemy import Column, Integer, String, JSON, ForeignKey
from ..db import Base

class Interview(Base):
    __tablename__ = "interviews"
    id = Column(Integer, primary_key=True, index=True)
    candidate_id = Column(Integer, ForeignKey("candidates.id"))
    status = Column(String, default="in_progress")  # in_progress|finished
    qa = Column(JSON, default=[])  # [{q, difficulty, timeLimit, answer, score}]
