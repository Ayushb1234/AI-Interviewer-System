from sqlalchemy import Column, Integer, String, JSON
from ..db import Base

class Candidate(Base):
    __tablename__ = "candidates"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=True)
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    resume_meta = Column(JSON, nullable=True)
    final_score = Column(Integer, nullable=True)
    summary = Column(String, nullable=True)
