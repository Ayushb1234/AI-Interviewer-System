import { useEffect, useState } from 'react'
import IntervieweePage from './pages/IntervieweePage'
import InterviewerPage from './pages/InterviewerPage'
import WelcomeBackModal from './components/WelcomeBackModal'

export default function App(){
  const [tab, setTab] = useState<'interviewee'|'interviewer'>('interviewee')
  const [showWB, setShowWB] = useState(false)
  useEffect(()=>{
    // show once per browser to signal persistence
    if (!localStorage.getItem('ai-interview-first')) {
      localStorage.setItem('ai-interview-first','1')
      setShowWB(true)
    }
  },[])
  return (
    <>
      <div className="tabs">
        <div className={`tab ${tab==='interviewee'?'active':''}`} onClick={()=>setTab('interviewee')}>Interviewee</div>
        <div className={`tab ${tab==='interviewer'?'active':''}`} onClick={()=>setTab('interviewer')}>Interviewer</div>
      </div>
      {tab==='interviewee' ? <IntervieweePage/> : <InterviewerPage/>}
      <WelcomeBackModal open={showWB} onClose={()=>setShowWB(false)}/>
    </>
  )
}
