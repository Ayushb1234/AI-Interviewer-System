import { useEffect, useState } from 'react'

export default function Timer({seconds, onZero}:{seconds:number, onZero:()=>void}) {
  const [t,setT] = useState(seconds)
  useEffect(()=>{
    if (t<=0) { onZero(); return }
    const id = setTimeout(()=>setT(t-1), 1000)
    return ()=>clearTimeout(id)
  },[t])
  return <div className="card">Time left: {t}s</div>
}
