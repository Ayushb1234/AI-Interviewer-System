import { useState } from 'react'
import Timer from './Timer'
import { useSelector, useDispatch } from 'react-redux'
import { RootState } from '../../store'
import { setAnswer, next, finish } from '../../store/slices/interviewSlice'
import { api } from '../../api/client'

export default function ChatBox(){
  const { qa, index, status, interviewId } = useSelector((s:RootState)=>s.interview)
  const dispatch = useDispatch()
  const [input, setInput] = useState('')

  const submit = async ()=>{
    if (interviewId==null) return
    const res = await api.post('/interview/answer', { interview_id: interviewId, index, answer: input || '(no answer)' })
    const newQA = res.data.qa
    const score = newQA[index].score ?? null
    dispatch(setAnswer({index, answer: input || '(no answer)', score}))
    setInput('')
    if (index === qa.length-1){
      await api.post('/interview/finish', null, { params: { interview_id: interviewId } })
      dispatch(finish())
    } else {
      dispatch(next())
    }
  }

  const autoSubmit = ()=>{ if (input.trim()==='') setInput('(no answer)'); submit() }

  if (status!=='in_progress') return <div className="card">Start the interview from the left pane.</div>
  const item = qa[index]
  return (
    <div className="card" style={{display:'grid', gap:12}}>
      <div><b>Q{index+1}/{qa.length}</b> [{item.difficulty}] — {item.q}</div>
      <Timer seconds={item.timeLimit} onZero={autoSubmit}/>
      <textarea value={input} onChange={e=>setInput(e.target.value)} rows={5} style={{width:'100%'}} placeholder="Type your answer..."/>
      <button className="tab" onClick={submit}>Submit</button>
    </div>
  )
}
