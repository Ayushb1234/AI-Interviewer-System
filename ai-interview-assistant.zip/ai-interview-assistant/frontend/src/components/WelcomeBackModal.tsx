export default function WelcomeBackModal({ open, onClose }:{open:boolean,onClose:()=>void}){
  if(!open) return null
  return (
    <div style={{position:'fixed', inset:0, display:'grid', placeItems:'center', background:'rgba(0,0,0,.6)'}}>
      <div className="card">
        <h3>Welcome back!</h3>
        <p>Your previous session was restored.</p>
        <button className="tab" onClick={onClose}>Let’s go</button>
      </div>
    </div>
  )
}
