import { useEffect, useState } from 'react'
import { api } from '../../api/client'

export default function CandidateDetail({ id }:{ id:number|null }){
  const [data,setData] = useState<any|null>(null)
  useEffect(()=>{ if(id) api.get('/candidates/'+id).then(r=>setData(r.data)) },[id])
  if (!id) return <div className="card">Select a candidate to view details.</div>
  if (!data) return <div className="card">Loading...</div>
  return (
    <div className="card" style={{display:'grid', gap:8}}>
      <b>{data.name||'Unnamed'}</b>
      <div>Email: {data.email||'—'} | Phone: {data.phone||'—'}</div>
      <div>Final Score: {data.final_score ?? '—'}</div>
      <div>Summary: {data.summary || '—'}</div>
    </div>
  )
}
