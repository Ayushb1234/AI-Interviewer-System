import { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { api } from '../../api/client'
import { setRows, setQuery } from '../../store/slices/dashboardSlice'
import { RootState } from '../../store'

export default function CandidateList({ onSelect }:{ onSelect:(id:number)=>void }){
  const dispatch = useDispatch()
  const { rows, query } = useSelector((s:RootState)=>s.dashboard)

  useEffect(()=>{ api.get('/candidates/').then(r=>dispatch(setRows(r.data))) },[dispatch])

  const filtered = rows
    .filter(r => (r.name||'').toLowerCase().includes(query.toLowerCase()))
    .sort((a,b)=> (b.final_score||0)-(a.final_score||0))

  return (
    <div className="card" style={{display:'grid', gap:12}}>
      <input placeholder="Search by name..." value={query} onChange={e=>dispatch(setQuery(e.target.value))}/>
      <div style={{display:'grid', gap:8}}>
        {filtered.map(r=>(
          <div key={r.id} className="tab" onClick={()=>onSelect(r.id)}>
            <b>{r.name||'Unnamed'}</b> — Score: {r.final_score ?? '—'}
            <div style={{opacity:.7, fontSize:12}}>{r.summary}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
