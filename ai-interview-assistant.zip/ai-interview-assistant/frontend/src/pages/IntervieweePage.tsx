import { useDispatch, useSelector } from 'react-redux'
import { useState } from 'react'
import { api } from '../api/client'
import { setCandidate } from '../store/slices/candidateSlice'
import { setMeta, setQA } from '../store/slices/interviewSlice'
import ChatBox from '../components/chat/ChatBox'
import { RootState } from '../store'

export default function IntervieweePage(){
  const dispatch = useDispatch()
  const { id } = useSelector((s:RootState)=>s.candidate)
  const [missing, setMissing] = useState<string[]>([])

  const onUpload = async (file: File)=>{
    const form = new FormData()
    form.append('file', file)
    const res = await api.post('/resume/upload', form, { headers: { 'Content-Type': 'multipart/form-data' } })
    const c = res.data
    dispatch(setCandidate({ id: c.candidate_id, ...c.extracted }))
    setMissing(c.missing_fields)
  }

  const start = async ()=>{
    if (!id) return
    const res = await api.post('/interview/start', { candidate_id: id })
    dispatch(setMeta({ interviewId: res.data.id, candidateId: res.data.candidate_id }))
    dispatch(setQA(res.data.qa))
  }

  return (
    <div className="container" style={{display:'grid', gap:16}}>
      <div className="card">
        <input type="file" accept=".pdf,.docx" onChange={e=>e.target.files && onUpload(e.target.files[0])}/>
        {missing.length>0 && <div style={{color:'#ffb86c', marginTop:8}}>Missing: {missing.join(', ')} — please provide via chat before starting.</div>}
        <button className="tab" style={{marginTop:12}} onClick={start}>Start Interview</button>
      </div>
      <ChatBox/>
    </div>
  )
}
