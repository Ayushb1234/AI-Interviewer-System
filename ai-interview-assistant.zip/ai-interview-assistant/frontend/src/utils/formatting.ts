export const formatSecs = (s:number)=>`${s}s`
