import { createSlice, PayloadAction } from '@reduxjs/toolkit'
type Candidate = { id: number|null, name?: string|null, email?: string|null, phone?: string|null }
const initialState: Candidate = { id: null, name: null, email: null, phone: null }
const slice = createSlice({
  name: 'candidate',
  initialState,
  reducers: {
    setCandidate(_, action: PayloadAction<Candidate>) { return action.payload }
  }
})
export const { setCandidate } = slice.actions
export default slice.reducer
