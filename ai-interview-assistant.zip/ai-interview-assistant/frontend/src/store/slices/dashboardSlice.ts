import { createSlice, PayloadAction } from '@reduxjs/toolkit'
type Row = { id:number, name?:string|null, email?:string|null, phone?:string|null, final_score?:number|null, summary?:string|null }
type State = { rows: Row[], query: string }
const initialState: State = { rows: [], query: '' }
const slice = createSlice({
  name:'dashboard',
  initialState,
  reducers:{
    setRows(state, action:PayloadAction<Row[]>) { state.rows = action.payload },
    setQuery(state, action:PayloadAction<string>) { state.query = action.payload }
  }
})
export const { setRows, setQuery } = slice.actions
export default slice.reducer
