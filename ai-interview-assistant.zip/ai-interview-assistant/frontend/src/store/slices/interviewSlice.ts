import { createSlice, PayloadAction } from '@reduxjs/toolkit'

export type QA = { q:string, difficulty:'easy'|'medium'|'hard', timeLimit:number, answer?:string|null, score?:number|null }
type InterviewState = { interviewId:number|null, candidateId:number|null, qa:QA[], status:'idle'|'in_progress'|'finished', index:number }
const initialState: InterviewState = { interviewId:null, candidateId:null, qa:[], status:'idle', index:0 }

const slice = createSlice({
  name:'interview',
  initialState,
  reducers:{
    hydrate(_, action:PayloadAction<InterviewState>) { return action.payload },
    setQA(state, action:PayloadAction<QA[]>) { state.qa = action.payload; state.index = 0 },
    setMeta(state, action:PayloadAction<{interviewId:number, candidateId:number}>) {
      state.interviewId = action.payload.interviewId; state.candidateId = action.payload.candidateId; state.status='in_progress'
    },
    setAnswer(state, action:PayloadAction<{index:number, answer:string, score:number|null}>) {
      const {index, answer, score} = action.payload; state.qa[index].answer = answer; state.qa[index].score = score
    },
    next(state){ state.index = Math.min(state.index+1, state.qa.length-1) },
    finish(state){ state.status='finished' }
  }
})
export const { hydrate, setQA, setMeta, setAnswer, next, finish } = slice.actions
export default slice.reducer
